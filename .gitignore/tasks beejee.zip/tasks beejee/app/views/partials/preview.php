<div class="container preview-div default-hide">
<h5 >Preview: </h5>
<div class="row">
    <div class="col-lg-5 col-md-6">
        <div class="img" id="preview-img" style="display:none"><img class="img-preview"></div> 
    </div>
    <div class="col-lg-7 col-md-6">
        <h7><i>Posted by: </i><i id="preview-username"></i></h7>
        <p><i id="preview-mail"></i></p>
        <p id="preview-text"></p>  
        <button type='button' class='taskId-{$task->id} btn btn-warning'>ACTIVE</button>
    </div>  
</div>
<hr>   
</div>