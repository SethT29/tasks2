export default function Head() {
  return (
    <head>
      <link rel="stylesheet" href="/assets/css/dashliteb12b.css" />
      <link id="skin-default" rel="stylesheet" href="/assets/css/themeb12b.css"></link>
      <title>Pannel d'administration</title>
      <meta content="width=device-width, initial-scale=1" name="viewport" />
      <meta name="description" content="Application d'envoie de rappel de rendez par sms" />
      <link rel="icon" href="/favicon.ico" />
      <link rel="manifest" href="/manifest.json" />
    </head>
  )
}
