"use client"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSession } from "next-auth/react";


export default function Home() {

    const router = useRouter();
    const { status } = useSession();

     useEffect(() => {
        console.log(status)
        if (status === "unauthenticated") {
            console.log(status)
            router.push("/login");
        } else if (status === "authenticated") {
            router.push("/dashboard");
        }
    }, [status]);

    return (
        <div className="nk-content " style={{display:"flex", justifyContent:"center", alignItems:"center", height:"100vh"}}>
            ...Chargement
        </div>    
    )
  }