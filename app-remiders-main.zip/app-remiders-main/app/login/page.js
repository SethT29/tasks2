"use client";

import React, { useState, useEffect } from "react";
import { message, Spin } from 'antd';
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

const Login = () => {

    const router = useRouter();
    const [messageApi, contextHolder] = message.useMessage()

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);

    const [toogleType, setToogleType] = useState("password")

    const toogleDisplayPassword = ()=>{
        if(toogleType==="password"){
            setToogleType("text")
        }else{
            setToogleType("password")
        }
    }

    const submitHandler = async (e) => {
        setLoading(true)
        e.preventDefault();

        try {
            if(email==="" || password===""){
                messageApi.open({
                    type: 'error',
                    content: 'Veuillez remplir tous les champs',
                });
                setLoading(false)
            }else{
                const data = await signIn("credentials", {
                    redirect: false,
                    email,
                    password,
                })
                if(data.ok){
                    router.push("/dashboard");
                }else{
                    setLoading(false)
                    messageApi.open({
                        type: 'error',
                        content: 'Email ou mot de passe incorrect',
                    });
                }
                
            }
        } catch (error) {
            setLoading(false)
            console.log(error);
           
        }
    };

  return (
    <div className="nk-app-root">
        {contextHolder}
        <div className="nk-main ">
            <div className="nk-wrap nk-wrap-nosidebar">
                <div className="nk-content ">
                    <div className="nk-block nk-block-middle nk-auth-body  wide-xs">
                        <div className="card card-bordered">
                          <div className="card-inner card-inner-lg">
                            <div className="nk-block-head">
                                <div className="nk-block-head-content">
                                    <h4 className="nk-block-title">S'identifier</h4>
                                    <div className="nk-block-des">
                                        <p>Accédez au pannel d'administration à l'aide de votre e-mail et de votre code d'accès.</p>
                                    </div>
                                </div>
                            </div>
                            <form onSubmit={submitHandler}>
                                <div className="form-group">
                                    <div className="form-label-group"><label className="form-label" htmlFor="default-01">Email
                                            </label></div>
                                    <div className="form-control-wrap"><input type="email"
                                            className="form-control form-control-lg"  value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            placeholder="Entrer votre email"/></div>
                                </div>
                                <div className="form-group">
                                    <div className="form-label-group"><label className="form-label"
                                            htmlFor="password">Mot de passe</label></div>
                                    <div className="form-control-wrap">
                                            <a href="#"
                                            className="form-icon form-icon-right passcode-switch lg"
                                            data-target="password" onClick={toogleDisplayPassword}>
                                                <em className="passcode-icon icon-show icon ni ni-eye"></em>
                                            </a>
                                                <input
                                                    type={toogleType} value={password}
                                                    onChange={(e) => setPassword(e.target.value)} className="form-control form-control-lg"
                                                    placeholder="Entrez votre mot de passe"/></div>
                                </div>
                                <div className="form-group">
                                    <Spin spinning={loading}><button  type="submit" className="btn btn-lg btn-primary btn-block">Se connecter</button></Spin>
                                </div>
                            </form>
                            
                        </div>
                        </div>
                    </div>
                    <div className="nk-footer nk-auth-footer-full">
                        <div className="container wide-lg">
                            <div className="row g-3">
                                <div className="col-lg-6 order-lg-last">
                                    <ul className="nav nav-sm justify-content-center justify-content-lg-end">
                                        <li className="nav-item"><a className="nav-link" href="#">Termes et conditions</a></li>
                                        <li className="nav-item"><a className="nav-link" href="#">Aide</a></li>
                                      
                                    </ul>
                                </div>
                                <div className="col-lg-6">
                                    <div className="nk-block-content text-center text-lg-start">
                                        <p className="text-soft">&copy; 2022 Clinique Remider App</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default Login;
