import { PrismaClient } from '@prisma/client';
import { uid } from 'uid';
const moment = require('moment/moment')
const prisma = new PrismaClient()

export default async function handler(req, res) {

    if (req.method === "POST") {
        const {sid, message, phone, date, name} = req.body.new_data

        var momentDate = moment(date, "YYYY-MM-DD HH:mm");
        var isoDate = momentDate.toISOString();

        console.log(isoDate)
        const appointment = await prisma.appointment.create({
            data : {
                id : uid(25),
                sid,
                body : message,
                date : isoDate,
                name, 
                phone,
                time : "00:00"
            }
        })
        res.status(200).json({ success : true, appointment : appointment})
                
    }    
}

