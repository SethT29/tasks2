"use client"
import React, { useState } from 'react';
import moment from 'moment';
import axios from "axios"
import { useRouter } from 'next/navigation'
import dayjs from 'dayjs';
import 'dayjs/locale/fr'
import { Button, Modal, Form, Input, Col, Row, AutoComplete, message, Spin } from 'antd';
dayjs.locale('fr')

const ModalForm = () => {

  const router = useRouter()
  const [form] = Form.useForm();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dateRdv, setDateRdv] = useState();
  const [messageApi, contextHolder] = message.useMessage()
  
  const [messages, setMessage] = useState([
    {
        value: 'Vous avez rendez-vous le ',
    },
  ])


  const [dateValue, setDateValue] = useState('');

  const minDate = new Date();
  minDate.setDate(minDate.getDate() + 1); // Définit la date minimum à demain
  const minDateString = minDate.toISOString().slice(0, 16); // Convertit la date minimum en format ISO

  const maxDate = new Date();
  maxDate.setDate(maxDate.getDate() + 7); // Définit la date maximum à 7 jours à partir du jour actuel
  const maxDateString = maxDate.toISOString().slice(0, 16); // Convertit la date maximum en format ISO

  const handleChange = (event) => {
    setDateValue(event.target.value);
    const scheldule = event.target.value
    setDateRdv(scheldule)
    setMessage([
        {
            value: "Vous avez rendez vous "+ dayjs(scheldule).format('dddd D MMMM  YYYY') + " à " +dayjs(scheldule).format('HH[h]mm') + " à la clinique Oservice",
        },
    ])
  }

  const onReset = () => {
    form.resetFields();
  };

  const showModal = () => {
    setIsModalOpen(true);
  };

  const isValidPhoneNumber = (phone_number)=>{
    if(phone_number.length){
        const pattern = /^\+(24162|24166|24174|24176|24177)\d+$/;
        return pattern.test(phone_number);
    }else{
        return false
    }
  }

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const onFinish = async(values) => {
    setLoading(true)
    if(isValidPhoneNumber(values.phone)){
        let data = {
            name : values.name,
            phone : values.phone,
            message : values.message,
            date : dateRdv
        }
        const send = await axios.post(process.env.URL_BASE+'/send-message',{data}).then(res=>{
            let new_data = {
                name : values.name,
                phone : values.phone,
                message : values.message,
                date : dateRdv,
                sid : res.data.message.sid
            }
            axios.post(process.env.URL_BASE+'/save-message', {new_data}).then(res=>{
                onReset()
                setMessage([
                    {
                        value: 'Vous avez rendez-vous le ',
                    },
                ])
                router.refresh("/dashboard")
                messageApi.open({
                    type: 'success',
                    content: "Enregistrement effectué, un message sera envoyé 24h avant la date du rdv",
                });
                setLoading(false)
                setIsModalOpen(false)
            }).catch(error=>{
                messageApi.open({
                    type: 'error',
                    content: "Une erreur c'est produite veuillez recommencer !",
                });
                setLoading(false)
            })
        })
    }else{
        messageApi.open({
            type: 'error',
            content: "  Numero de téphone incorrect, exemple de format : +241XXXXXXXX ",
        });
        setLoading(false)
    }
  };
  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
    setLoading(false)
  };

  return (
    <>
        
      <Button type="primary" onClick={showModal}>
        Ajouter un rendez vous
      </Button>
      <Modal title="" open={isModalOpen} onOk={handleOk} footer={null} onCancel={handleCancel}>
      {contextHolder}
        <Spin spinning={loading} tip="Enregistrement...">
            <Form
                name="basic"
                labelCol={{
                    span: 8,
                }}
                wrapperCol={{
                    span: 24,
                }}
                style={{
                    maxWidth: 600,
                    marginTop:20
                }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
                layout="vertical"
                form={form}
            >
                <Form.Item
                    label="Nom et prenom"
                    name="name"
                    rules={[
                        {
                        required: true,
                        message: 'Veuillez renseigner le nom du patient !',
                        },
                    ]}
                >
                    <Input placeholder='nom du patient'/>
                </Form.Item>

                <Row>
                    <Col span={12}>
                        <Form.Item label="Date">
                            <input type="datetime-local" style={{paddingInline:"10px", paddingTop:"4px", paddingBottom:"4px", borderRadius:"3px", border:"1px solid gray"}} value={dateValue} onChange={handleChange} min={minDateString} max={maxDateString} />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            label="Téléphone"
                            name="phone"
                            placeholder="+241XXXXXXXX"
                            rules={[
                                {
                                required: true,
                                message: 'Renseigner le numero de téléphone !',
                                },
                            ]}
                        >
                            <Input placeholder='+241XXXXXXXX'/>
                        </Form.Item>
                    </Col>
                </Row>
            
                <Form.Item
                    label="message"
                    name="message"
                    rules={[
                        {
                        required: true,
                        message: 'Saisissez le message à envoyer!',
                        },
                    ]}
                >
                    <AutoComplete
                        style={{
                        width: "100%",
                        }}
                        options={messages}
                        placeholder="Entrez le message"
                        filterOption={(inputValue, option) =>
                            option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                        }
                    />
                </Form.Item>

            
                <Form.Item
                    wrapperCol={{
                        offset: 0,
                        span: 16,
                    }}
                >
                    <Button type="primary" htmlType="submi  t">
                        Enregistrer
                    </Button>
                </Form.Item>
            </Form>
        </Spin>
      </Modal>
    </>
  );
};

export default ModalForm;