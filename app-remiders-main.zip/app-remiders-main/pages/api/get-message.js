import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient()

export default async function handler(req, res) {
    try {
        //const messages = await client.messages.list({limit:200})
        const appointments = await prisma.appointment.findMany({
            orderBy: [
              {
                date: 'desc',
              },
        ]})
         // const result = appointments.filter(appointment => {
            //return messages.some(message => {
              // return appointment.sid === message.sid;
            // });
        // });
        return appointments;
    } catch (err) {
        console.error(err);
    } 
}

