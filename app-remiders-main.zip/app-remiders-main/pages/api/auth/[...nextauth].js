import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

export default NextAuth({
  session: {
    strategy: "jwt",
  },
  providers: [
    CredentialsProvider({
      async authorize(credentials, req) {

        const users = [
          {name : "Gabin Moundziegou" , username:"Gabin", email:"gabinmoundziegou@gmail.com", password : "motdepasse", id:1},
          {name: "Tayan",   username:"Tayan", email:"tayan@gmail.com", password : "motdepasse", id:2}
        ]

        let findUser = users.find( identity => identity.email === credentials.email );
        

        if( findUser.password === credentials.password ) {
            const user = { id: findUser.id, name: findUser.name, email: findUser.email, username:findUser.username }
            return user
        }
        return null
      },
    }),
  ],
  pages: {
    signIn: "/login",
  },
  secret: process.env.NEXTAUTH_SECRET,
});
