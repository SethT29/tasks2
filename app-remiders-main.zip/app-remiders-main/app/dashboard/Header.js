"use client"
import React from "react";
import { useSession, signOut } from "next-auth/react";

const Header = () => {

  const { data } = useSession();

  return (
    <div className="nk-header nk-header-fixed">
        <div className="container-fluid">
            <div className="nk-header-wrap">
                <div className="nk-menu-trigger d-xl-none ms-n1"><a href="#"
                        className="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em
                            className="icon ni ni-menu"></em></a></div>
                <div className="nk-header-brand d-xl-none"><a href="/dashboard" className="logo-link"></a></div>
                <div className="nk-header-news d-none d-xl-block">
                    <div className="nk-news-list"><a className="nk-news-item" href="#">
                            <div className="nk-news-icon"><em className="icon ni ni-card-view"></em></div>
                            <div className="nk-news-text">
                                {/**<p> Je suis Gabin Moundziegou !  <span> Si vous avez des questions cliquez ici ! </span></p><em className="icon ni ni-external"></em>**/}
                            </div>
                        </a></div>
                </div>
                <div className="nk-header-tools">
                    <ul className="nk-quick-nav">
                        
                        <li className="dropdown user-dropdown"><a href="#" className="dropdown-toggle"
                                data-bs-toggle="dropdown">
                                <div className="user-toggle">
                                    <div className="user-avatar sm"><em className="icon ni ni-user-alt"></em></div>
                                    <div className="user-info d-none d-md-block">
                                        <div className="user-status">Administrateur</div>
                                        <div className="user-name dropdown-indicator">{data?.user && data.user.name}</div>
                                    </div>
                                </div>
                            </a>
                            <div className="dropdown-menu dropdown-menu-md dropdown-menu-end dropdown-menu-s1">
                                <div className="dropdown-inner user-card-wrap bg-lighter d-none d-md-block">
                                    <div className="user-card">
                                        
                                        <div className="user-info"><span className="lead-text">{data?.user && data.user.name}</span><span
                                                className="sub-text">{data?.user && data.user.email}</span></div>
                                    </div>
                                </div>
                               {/** <div className="dropdown-inner">
                                    <ul className="link-list">
                                        <li><Link href="/dashboard/parametres"><em
                                                    className="icon ni ni-setting-alt"></em><span>Parametres</span></Link></li>
                                        
                                    </ul>
                                </div> */}
                                <div className="dropdown-inner">
                                    <ul className="link-list">
                                        <li><a style={{cursor:"pointer"}} onClick={() => signOut()}><em className="icon ni ni-signout"></em><span>Deconnexion</span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                      
                    </ul>
                </div>
            </div>
        </div>
    </div>
  );
};

export default Header;
