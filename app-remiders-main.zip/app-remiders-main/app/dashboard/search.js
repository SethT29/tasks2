"use client"
import { createContext } from 'react';
import { Input } from 'antd'
const { Search } = Input;

function Search() {
  return (
    <Search placeholder="input search text" enterButton />
  )
}

export default Search