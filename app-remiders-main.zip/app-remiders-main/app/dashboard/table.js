"use client"
import React, {useState, useEffect} from 'react'
import { Input } from 'antd';
const { Search } = Input;
import dayjs from 'dayjs';
import 'dayjs/locale/fr'
import utc from "dayjs/plugin/utc"
import days from 'moment';
dayjs.extend(utc)
dayjs.locale('fr')


const Table = ({messages}) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [appointments, setAppointments] = useState([])

    const handleChange = event => {
        setSearchTerm(event.target.value);
    };
    
    const filteredAppointments = appointments.filter(appointment =>
        appointment.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    useEffect(() => {
        setAppointments(messages)
    }, [messages])

  return (
    <>
        <Search
            placeholder="Rechercher un patient"
            onChange={handleChange}
            style={{marginBottom:10, width:300}}
        />
        <div className="nk-block">
            <div className="card card-bordered card-stretch">
                <div className="card-inner-group">
                    
                    <div className="card-inner p-0">
                        <div className="nk-tb-list nk-tb-ulist">
                            <div className="nk-tb-item nk-tb-head">
                                
                                <div className="nk-tb-col"><span className="sub-text">Nom du patient</span></div>
                                <div className="nk-tb-col tb-col-mb"><span
                                        className="sub-text">Date du rendez-vous</span></div>
                                <div className="nk-tb-col tb-col-md"><span
                                        className="sub-text">Numero de téléphone</span></div>
                                <div className="nk-tb-col tb-col-mb"><span
                                        className="sub-text">Message </span></div>
                                
                            </div>
                            { filteredAppointments.map((appointment, key)=>(
                                <div className="nk-tb-item" key={key}>
                                    <div className="nk-tb-col"><a>
                                            <div className="user-card">
                                                <div className="user-info"><span className="tb-lead">{appointment.name}</span>
                                                </div>
                                            </div>
                                        </a></div>
                                    <div className="nk-tb-col tb-col-mb">
                                    <span className="tb-lead">{dayjs(appointment.date).format('dddd D MMMM  YYYY')}<span
                                                                        className="dot dot-success d-md-none ml-1"></span></span><span>{days(appointment.date).utc().local().format('HH[H]mm')}</span>
                                    </div>
                                    <div className="nk-tb-col tb-col-md"><span>{appointment.phone}</span>
                                    </div>
                                    <div className="nk-tb-col tb-col-md"><span>{appointment.body}</span>
                                    </div>
                                </div>
                                )
                            )}
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </>
    )

}

export default Table;
