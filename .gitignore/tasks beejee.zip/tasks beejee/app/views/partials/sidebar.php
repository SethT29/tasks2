<div class="sidebar-module sidebar-module-inset">
SIDEBAR
</div>