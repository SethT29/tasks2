/** @type {import('next').NextConfig} */

const withPWA = require("@ducanh2912/next-pwa").default({
  dest: "public",
});

const nextConfig = {
  reactStrictMode: true,
  eslint: {
    // Warning: This allows production builds to successfully complete even if
    // your project has ESLint errors.
    ignoreDuringBuilds: true,
  },
  experimental: {
    appDir: true,
  },
  env: {
    NEXTAUTH_SECRET: "remidersapp",
    URL_BASE : "https://app-remiders.vercel.app/api"
  },
};

module.exports = withPWA(nextConfig);
