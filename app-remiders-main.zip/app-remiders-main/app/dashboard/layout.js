"use client";
import Header from "./Header"
import Script from "next/script";
import { SessionProvider } from "next-auth/react";

export const metadata = {
  title: "Dashboard (app)",
};

export default function DashboardLayout({ children }) {
  return (
    <html>
      <head/>
      <body className="nk-body bg-lighter npc-general has-sidebar no-touch nk-nio-theme">
        <SessionProvider>
          <div className="nk-app-root">
            <div className="nk-main ">
              <div className="nk-main">
                <div className="nk-wrap ">
                  <Header/>
                  {children}
                </div>
              </div>
            </div>
          </div>
        </SessionProvider>
        <Script src="/assets/js/bundleb12b.js?ver=3.1.1"></Script>
        <Script src="/assets/js/scriptsb12b.js?ver=3.1.1"></Script>
      </body>
    </html>
  );
}
