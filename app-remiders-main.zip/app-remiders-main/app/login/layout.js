"use client"
import { SessionProvider } from "next-auth/react";

export const metadata = {
  title: "Login (app)",
};

export default function LoginLayout({ children }) {
    return (
      <html lang="fr">
        {/*
          <head /> will contain the components returned by the nearest parent
          head.jsx. Find out more at https://beta.nextjs.org/docs/api-reference/file-conventions/head
        */}
        <head>
          <link rel="stylesheet" href="/assets/css/dashliteb12b.css"/>
          <link id="skin-default" rel="stylesheet" href="/assets/css/themeb12b.css"/>
          <meta content="width=device-width, initial-scale=1" name="viewport" />
          <link rel="icon" href="/favicon.ico" />
          <link rel="manifest" href="/manifest.json" />
        </head>
        <body className="nk-body bg-lighter npc-general pg-auth k-nio-theme">
        <SessionProvider>
          {children}
        </SessionProvider>

        </body>
      </html>
    )
  }