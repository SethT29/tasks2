"use client"
import { SessionProvider } from "next-auth/react";

const APP_NAME = "remiders-sms";
const APP_DESCRIPTION = "Application de rappel de rendez vous";

export const metadata = {
  applicationName: APP_NAME,
  title: {
    default: APP_NAME,
    template: "%s - PWA App",
  },
  description: APP_DESCRIPTION,
  manifest: "/manifest.json",
  themeColor: "#FFFFFF",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: APP_NAME,
  },
  formatDetection: {
    telephone: false,
  },
  icons: {
    shortcut: "/favicon.ico",
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180" }],
  },
};

export default function RootLayout({ children }) {
    return (
      <html>
        <head>
          <link rel="manifest" href="/manifest.json" />
        </head>
        <body className="nk-body bg-lighter npc-general has-sidebar no-touch nk-nio-theme">
            <SessionProvider>
                {children}
            </SessionProvider>
        </body>
      </html>
    );
  }