import Form from "./form"
import Table from "./table";
import { PrismaClient } from "@prisma/client";
import moment from "moment";
const prisma = new PrismaClient()
moment.locale(); 

export const revalidate = 0


export default async function Dashboard() {
  
    const messages = await prisma.appointment.findMany({
        orderBy: [
          {
            date: 'desc',
          },
    ]})

  return (
    <div className="nk-content ">
        <div className="container-fluid">
            <div className="nk-content-inner">
                <div className="nk-content-body">
                    <div className="nk-block-head nk-block-head-sm">
                        <div className="nk-block-between">
                            <div className="nk-block-head-content">
                                <h3 className="nk-block-title page-title">Listes des rendez-vous</h3>
                            </div>
                            <div className="nk-block-head-content">
                                <div className="toggle-wrap nk-block-tools-toggle"><a href="#"
                                        className="btn btn-icon btn-trigger toggle-expand mr-n1"
                                        data-target="pageMenu"><em className="icon ni ni-menu-alt-r"></em></a>
                                    <div className="toggle-expand-content" data-content="pageMenu">
                                        <ul className="nk-block-tools g-3">
                                            <li>
                                                <Form/>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <Table messages={messages}/>
                </div>
            </div>
        </div>
       
    </div>   
  )
}
