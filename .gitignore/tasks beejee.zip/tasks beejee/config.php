<?php

return [
	'database' => [
		'name' => 'beejee',
		'username' => 'root',
		'password' => 'root',
		'connection' => 'mysql:host=localhost',
		'options' => [
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
		]
	]
];		