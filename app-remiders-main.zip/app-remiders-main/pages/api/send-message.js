const accountSid = "AC6f0c1f08786f625faafdeff980cb683c";
const authToken = "ae8d09d42dc7459ec5ff728f94f53731";
const client = require('twilio')(accountSid, authToken);
const moment = require('moment/moment')

export default async function handler(req, res) {
  if (req.method === "POST") {
        const {name, phone, message, date} = req.body.data

        var momentDate = moment(date, "YYYY-MM-DD HH:mm");
        momentDate = momentDate.subtract(1, "days")
        console.log(momentDate)
        var isoDate = momentDate.toISOString();

        console.log(isoDate)

        const send_message = await client.messages.create({
          messagingServiceSid: 'MG09eee63227735a5a072ec3ab40ed46c0',
          sendAt: isoDate,
          scheduleType: 'fixed',
          body: message,
          to: phone
        })

        res.status(201).json({ success : true, message : send_message})

    };
          
}

